Compiled using javac inside the directory of the source code and the board file:
	javac -cp . *.java
Run using java inside same directory
	java -cp . EightPieceGame <board text file>

The board text file name must simply be the last argument.